import React, { Component } from 'react';

class MessageClass extends Component {
  render() {
    return (
      <div>MessageClass {this.props.text}</div>
    );
  }
}

export default MessageClass;
